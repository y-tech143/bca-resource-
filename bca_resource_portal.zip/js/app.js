/**
 * Application Core controller for UI, searching, routing, and component states.
 */

let masterCurriculumData = {};
let activeSelectedSubject = null;
let currentCategoryFilter = 'notes';

document.addEventListener("DOMContentLoaded", async () => {
    // Render dynamic structures
    await initApplicationHub();

    // Setup Theme Engine
    initThemeEngine();

    // Event Bindings
    setupEventInterceptors();
});

async function initApplicationHub() {
    const mask = document.getElementById("loaderMask");
    
    // Read centralized config repositories
    const liveNotices = await DataFetcher.getLiveNotices();
    masterCurriculumData = await DataFetcher.getAcademicCurriculumMap();

    renderNoticeBoard(liveNotices);
    renderMetricsCounters(masterCurriculumData.statistics);
    renderSemesterCards(masterCurriculumData.semesters);

    if(mask) mask.classList.add("hidden");
}

/* Notice Matrix Builder Engine */
function renderNoticeBoard(notices) {
    const container = document.getElementById("noticesStream");
    const extendedContainer = document.getElementById("extendedNoticesView");
    if (!container) return;

    let htmlPayload = "";
    notices.forEach(item => {
        htmlPayload += `
            <div class="notice-stream-item">
                <div class="notice-meta-line">
                    <span class="badge">${item.tag}</span>
                    <span><i class="fa-regular fa-calendar"></i> ${item.date}</span>
                </div>
                <h5>${item.title}</h5>
                <p style="font-size: 0.85rem; color: var(--text-secondary); margin-top:6px;">${item.desc}</p>
            </div>
        `;
    });

    container.innerHTML = htmlPayload;
    if(extendedContainer) extendedContainer.innerHTML = `<div class="notices-archive-stack" style="display:flex; flex-direction:column; gap:1.5rem; padding:1rem;">${htmlPayload}</div>`;
}

/* Metrics Generator Engine */
function renderMetricsCounters(stats) {
    const grid = document.getElementById("metricsCounterGrid");
    if(!grid || !stats) return;

    grid.innerHTML = `
        <div class="metric-card">
            <div class="metric-icon"><i class="fa-solid fa-file-pdf"></i></div>
            <div class="metric-info"><h4>${stats.totalNotes}</h4><p>Revision Notes</p></div>
        </div>
        <div class="metric-card">
            <div class="metric-icon"><i class="fa-solid fa-book"></i></div>
            <div class="metric-info"><h4>${stats.downloadablePdfs}</h4><p>Reference E-Books</p></div>
        </div>
        <div class="metric-card">
            <div class="metric-icon"><i class="fa-solid fa-graduation-cap"></i></div>
            <div class="metric-info"><h4>${stats.solvedExams}</h4><p>Guess Papers</p></div>
        </div>
        <div class="metric-card">
            <div class="metric-icon"><i class="fa-solid fa-users"></i></div>
            <div class="metric-info"><h4>${stats.activeUsers}</h4><p>Active Students</p></div>
        </div>
    `;
}

/* Semester UI Building Process */
function renderSemesterCards(semesters) {
    const targetGrid = document.getElementById("semestersGrid");
    if(!targetGrid) return;

    let gridHtml = "";
    semesters.forEach(sem => {
        let subjectRowsHtml = "";
        sem.subjects.forEach((sub, subIdx) => {
            subjectRowsHtml += `
                <div class="subject-pill-row" onclick="launchResourceModal(${sem.id}, ${subIdx})">
                    <span><strong>${sub.code}</strong> - ${sub.title}</span>
                    <i class="fa-solid fa-chevron-right"></i>
                </div>
            `;
        });

        gridHtml += `
            <div class="semester-container-card">
                <div class="sem-header">${sem.name}</div>
                <div class="subject-pills-stack">
                    ${subjectRowsHtml || '<p style="color:var(--text-secondary); font-size:0.85rem;">No subjects populated yet.</p>'}
                </div>
            </div>
        `;
    });

    targetGrid.innerHTML = gridHtml;
}

/* Interlock UI Navigation Mechanisms */
function setupEventInterceptors() {
    // Modular Page Tab Switcher Routing
    document.querySelectorAll(".menu-item").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.preventDefault();
            document.querySelectorAll(".menu-item").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            const targetSectionId = btn.getAttribute("data-target");
            switchTab(targetSectionId);
        });
    });

    // Close Modal Bindings
    const closeBtn = document.getElementById("closeModalBtn");
    if(closeBtn) {
        closeBtn.addEventListener("click", () => {
            document.getElementById("resourceModal").classList.remove("open");
        });
    }

    // Modal Resource Category Tabs Interaction Interceptor
    document.querySelectorAll(".cat-tab").forEach(tab => {
        tab.addEventListener("click", () => {
            document.querySelectorAll(".cat-tab").forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            currentCategoryFilter = tab.getAttribute("data-cat");
            populateModalFilesList();
        });
    });

    // Global Live Search Logic
    const searchInput = document.getElementById("globalSearch");
    if(searchInput) {
        searchInput.addEventListener("input", (e) => executeGlobalIncrementalSearch(e.target.value));
    }

    // Back to top implementation code logic
    const topBtn = document.getElementById("scrollTop");
    window.addEventListener("scroll", () => {
        if(window.scrollY > 300) topBtn.classList.add("visible");
        else topBtn.classList.remove("visible");
    });
    if (topBtn) {
        topBtn.addEventListener("click", () => window.scrollTo({top:0, behavior:'smooth'}));
    }

    // Mobile Navigation Handlers
    const mobileMenuOpen = document.getElementById("mobileMenuOpen");
    const sidebar = document.getElementById("sidebar");
    if(mobileMenuOpen && sidebar) {
        mobileMenuOpen.addEventListener("click", () => {
            sidebar.classList.toggle("mobile-open");
        });
    }
}

function switchTab(targetId) {
    document.querySelectorAll(".workspace-tab").forEach(tab => tab.classList.remove("active-tab"));
    const selectedTab = document.getElementById(targetId);
    if(selectedTab) selectedTab.classList.add("active-tab");
}

/* Dynamic Open Drawer Engine */
function launchResourceModal(semesterId, subjectIndex) {
    const targetSemester = masterCurriculumData.semesters.find(s => s.id === semesterId);
    activeSelectedSubject = targetSemester.subjects[subjectIndex];

    document.getElementById("modalSubjectTitle").innerText = activeSelectedSubject.title;
    document.getElementById("modalSemesterBadge").innerText = targetSemester.name;
    
    // Reset defaults
    currentCategoryFilter = "notes";
    document.querySelectorAll(".cat-tab").forEach(t => {
        t.classList.remove("active");
        if(t.getAttribute("data-cat") === "notes") t.classList.add("active");
    });

    populateModalFilesList();
    document.getElementById("resourceModal").classList.add("open");
}

/* File Node Injector Engine */
function populateModalFilesList() {
    const viewport = document.getElementById("modalFilesViewport");
    if(!viewport || !activeSelectedSubject) return;

    const fileArray = activeSelectedSubject.resources[currentCategoryFilter] || [];
    if(fileArray.length === 0) {
        viewport.innerHTML = `
            <div style="text-align:center; padding:3rem; color:var(--text-secondary);">
                <i class="fa-solid fa-folder-open" style="font-size:3rem; margin-bottom:1rem; opacity:0.3;"></i>
                <p>No documents uploaded yet for this specific sub-category.</p>
            </div>
        `;
        return;
    }

    let cardsHtml = '<div class="files-action-grid">';
    fileArray.forEach(file => {
        cardsHtml += `
            <div class="file-resource-card">
                <div class="file-title-block">
                    <i class="fa-solid fa-file-pdf"></i>
                    <h6>${file.title}</h6>
                </div>
                <a href="${file.fileLink}" download class="btn-download-action">
                    <i class="fa-solid fa-cloud-arrow-down"></i> Download File
                </a>
            </div>
        `;
    });
    cardsHtml += '</div>';
    viewport.innerHTML = cardsHtml;
}

/* Global Real-time Search Execution Engine */
function executeGlobalIncrementalSearch(queryString) {
    const dropdown = document.getElementById("searchResults");
    if(!queryString.trim()) {
        dropdown.style.display = "none";
        return;
    }

    let matchCount = 0;
    let payloadHtml = "";

    masterCurriculumData.semesters.forEach(sem => {
        sem.subjects.forEach((sub, sIdx) => {
            if(sub.title.toLowerCase().includes(queryString.toLowerCase()) || sub.code.toLowerCase().includes(queryString.toLowerCase())) {
                matchCount++;
                payloadHtml += `
                    <div class="search-result-row" onclick="launchResourceModal(${sem.id}, ${sIdx})">
                        <i class="fa-solid fa-book"></i> <span>${sub.code} - ${sub.title} (${sem.name})</span>
                    </div>
                `;
            }
        });
    });

    if(matchCount > 0) {
        dropdown.innerHTML = payloadHtml;
        dropdown.style.display = "block";
    } else {
        dropdown.innerHTML = `<div style="padding:12px; color:var(--text-secondary); font-size:0.85rem;">No subject matching input query found.</div>`;
        dropdown.style.display = "block";
    }
}

/* Universal Light / Dark Theme Architecture Engine */
function initThemeEngine() {
    const toggle = document.getElementById("themeToggle");
    if(!toggle) return;

    toggle.addEventListener("click", () => {
        document.body.classList.toggle("light-theme");
        const isLight = document.body.classList.contains("light-theme");
        toggle.innerHTML = isLight ? `<i class="fa-solid fa-sun"></i> <span>Light Mode</span>` : `<i class="fa-solid fa-moon"></i> <span>Dark Mode</span>`;
    });
}