/**
 * Data Management Engine for the BCA Educational Portal
 * Responsible for simulating REST endpoints and reading clean static JSON configurations.
 */

class DataFetcher {
    // Fetches live updates and news releases
    static async getLiveNotices() {
        try {
            const response = await fetch('data/notices.json');
            if (!response.ok) throw new Error("Notice API stream breakdown.");
            return await response.json();
        } catch (error) {
            console.error("Critical: Live notice configuration failure. Using mock fallback.", error);
            return [
                { "id": 1, "date": "2026-05-25", "tag": "Exam", "title": "BCA Sem II, IV & VI Main Examination Form Submissions Extended", "desc": "University of Rajasthan online form entry extended with regular fees until end of week." },
                { "id": 2, "date": "2026-05-24", "tag": "Admit Card", "title": "Download Theory Hall Tickets for BCA Practical/Theory Labs", "desc": "Students are directed to fetch digital credentials directly from the main server using registration sequences." }
            ];
        }
    }

    // Fetches entire dictionary dataset containing Semesters, Subjects, and nested Files paths
    static async getAcademicCurriculumMap() {
        try {
            const response = await fetch('data/semester_data.json');
            if (!response.ok) throw new Error("Curriculum catalog broken link.");
            return await response.json();
        } catch (error) {
            console.error("Critical Dynamic File configuration read error. Standard fallback processing activated.", error);
            return {
                "semesters": [
                    {
                        "id": 1,
                        "name": "BCA Semester 1",
                        "subjects": [
                            {
                                "code": "BCA-101",
                                "title": "HTML & Web Design",
                                "resources": {
                                    "notes": [
                                        { "title": "Unit I - Tags, Elements & Boilerplate structures", "fileLink": "notes/html/unit1_tags.pdf" },
                                        { "title": "Unit II - Interactive CSS Layouts & Tables", "fileLink": "notes/html/unit2_css.pdf" }
                                    ],
                                    "pdfs": [
                                        { "title": "Complete Reference HTML 5th Edition Complete Book", "fileLink": "pdfs/html/reference_book.pdf" }
                                    ],
                                    "guessPapers": [
                                        { "title": "Expected 2026 Most Critical Exam Guess Questions", "fileLink": "pdfs/html/guess_paper_2026.pdf" }
                                    ],
                                    "prevPapers": [
                                        { "title": "University Main Examination Paper 2025", "fileLink": "pdfs/html/uniraj_paper_2025.pdf" }
                                    ],
                                    "assignments": [],
                                    "practicals": [
                                        { "title": "Lab List Challenge Index 1-15 (Formatted)", "fileLink": "pdfs/html/lab_workbook.pdf" }
                                    ]
                                }
                            },
                            {
                                "code": "BCA-102",
                                "title": "C Programming Language Core",
                                "resources": { "notes": [], "pdfs": [], "guessPapers": [], "prevPapers": [], "assignments": [], "practicals": [] }
                            }
                        ]
                    }
                ],
                "statistics": { "totalNotes": 142, "downloadablePdfs": 89, "solvedExams": 45, "activeUsers": "1.2K+" }
            };
        }
    }
}